@extends('backend.layouts.master')

@section('main-content')

<div class="card">
    <h5 class="card-header">Edit Car</h5>
    <div class="card-body">
      <form method="post" action="{{route('Car.update',$Car->id)}}" enctype="multipart/form-data">
        @csrf 
        @method('PATCH')
        <div class="form-group">
          <label for="inputTitle" class="col-form-label">Title Français <span class="text-danger">*</span></label>
          <input id="inputTitle" type="text" name="title" placeholder="Enter title"  value="{{$Car->title}}" class="form-control">
          @error('title')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="summary" class="col-form-label">Summary Français <span class="text-danger">*</span></label>
          <textarea class="form-control" id="summary" name="summary">{{$Car->summary}}</textarea>
          @error('summary')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="description" class="col-form-label">Description Français</label>
          <textarea class="form-control" id="description" name="description">{{$Car->description}}</textarea>
          @error('description')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="inputTitle" class="col-form-label">Title Englais <span class="text-danger">*</span></label>
          <input id="inputTitle" type="text" name="titleEN" placeholder="Enter title"  value="{{$Car->titleEN}}" class="form-control">
          @error('titleEN')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="summary" class="col-form-label">Summary Englais <span class="text-danger">*</span></label>
          <textarea class="form-control" id="summary" name="summaryEN">{{$Car->summaryEN}}</textarea>
          @error('summaryEN')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="description" class="col-form-label">Description Englais</label>
          <textarea class="form-control" id="description" name="descriptionEN">{{$Car->descriptionEN}}</textarea>
          @error('descriptionEN')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>


        <div class="form-group">
          <label for="is_featured">Is Featured</label><br>
          <input type="checkbox" name='is_featured' id='is_featured' value='{{$Car->is_featured}}' {{(($Car->is_featured) ? 'checked' : '')}}> Yes                        
        </div>
              {{-- {{$categories}} --}}

        <div class="form-group">
          <label for="cat_id">Category <span class="text-danger">*</span></label>
          <select name="cat_id" id="cat_id" class="form-control">
              <option value="">--Select any category--</option>
              @foreach($categories as $key=>$cat_data)
                  <option value='{{$cat_data->id}}' {{(($Car->cat_id==$cat_data->id)? 'selected' : '')}}>{{$cat_data->title}}</option>
              @endforeach
          </select>
        </div>
        @php 
          $sub_cat_info=DB::table('categories')->select('title')->where('id',$Car->child_cat_id)->get();
        // dd($sub_cat_info);

        @endphp
        {{-- {{$Car->child_cat_id}} --}}
        <div class="form-group {{(($Car->child_cat_id)? '' : 'd-none')}}" id="child_cat_div">
          <label for="child_cat_id">Sub Category</label>
          <select name="child_cat_id" id="child_cat_id" class="form-control">
              <option value="">--Select any sub category--</option>
              
          </select>
        </div>

        <div class="form-group" id="size-inputs">
          <label for="size">Taille <span class="text-danger">*</span></label>
          <button type="button" class="btn btn-warning ml-2" id="add-size">Ajouter</button>
          <input type="hidden" id="size-count" name="size_count">
          @if($Car->sizes)                    
            @foreach ($Car->sizes as $key => $productsize)
                @if($key == 0)
                  <div class="size-input-{{$key}} row mt-3">
                    <div class="col-10">
                      <div class="row">
                        <div class="col-md-4 mb-2">
                          <input id="size-{{$key}}" type="text" name="size_{{$key}}" placeholder="Entrer la taille Français" value="{{ $productsize->size }}" class="form-control">
                        </div>
                        <div class="col-md-4 mb-2">
                          <input id="sizeEN-{{$key}}" type="text" name="sizeEN_{{$key}}" placeholder="Entrer la taille Anglais" value="{{ $productsize->sizeEN }}" class="form-control">
                        </div>
                        <div class="col-md-4 mb-2">
                            <input id="price-{{$key}}" type="text" name="price_{{$key}}" placeholder="Enter le prix" value="{{ $productsize->price }}" class="form-control">
                        </div>
                      </div>
                    </div>
                  </div>
                @else
                  <div class="size-input-{{$key}} row mt-3">
                    <div class="col-10">
                      <div class="row">
                        <div class="col-md-4 mb-2">
                          <input id="size-{{$key}}" type="text" name="size_{{$key}}" placeholder="Entrer la taille Français" value="{{ $productsize->size }}" class="form-control">
                        </div>
                        <div class="col-md-4 mb-2">
                          <input id="sizeEN-{{$key}}" type="text" name="sizeEN_{{$key}}" placeholder="Entrer la taille Anglais" value="{{ $productsize->size }}" class="form-control">
                        </div>
                        <div class="col-md-4 mb-2">
                          <input id="price-{{$key}}" type="text" name="price_{{$key}}" placeholder="Enter le prix" value="{{ $productsize->price }}" class="form-control">
                        </div>
                      </div>
                    </div>
                    <div class="col-1 d-flex align-items-center text-right">
                        <button type="button" class="btn btn-danger remove-size" data-id="{{$key}}"> <i class="fas fa-trash"></i> </button>
                    </div>
                  </div>
                @endif
            @endforeach
          @endif
          <script>
              var productsizes = @json($Car->sizes);
              var count = 1;
              if(productsizes) {
                var count = productsizes.length;
                $('#size-count').val(count);
              }
      
              $('#add-size').on('click', () => {
                  html = `<div class="size-input-${count} row mt-3">
                          <div class="col-10">
                            <div class="row">
                              <div class="col-md-4 mb-2">
                                <input id="size-${count}" type="text" name="size_${count}" placeholder="Entrer la taille Français" class="form-control">
                              </div>
                              <div class="col-md-4 mb-2">
                                <input id="sizeEN-${count}" type="text" name="sizeEN_${count}" placeholder="Entrer la taille Anglais" class="form-control">
                              </div>
                              <div class="col-md-4 mb-2">
                                  <input id="price-${count}" type="text" name="price_${count}" placeholder="Enter le prix" class="form-control">
                              </div>
                            </div>
                          </div>
                          <div class="col-1 d-flex align-items-center text-right">
                              <button type="button" class="btn btn-danger remove-size" data-id="${count}"> <i class="fas fa-trash"></i> </button>
                          </div>
                      </div>`;
                  $('#size-inputs').append(html);
                  count++;
                  $('#size-count').val(count);
      
                  $('.remove-size').on('click', function () {
                      var id = $(this).data('id');
                      $('.size-input-' + id).remove();
                  });
              });
      
              $('.remove-size').on('click', function () {
                  var id = $(this).data('id');
                  $('.size-input-' + id).remove();
              });
      
          </script>
          {{-- <select name="size[]" class="form-control selectpicker"  multiple data-live-search="true">
            <option value="">--Select any size--</option>
            <option value="S">Small (S)</option>
            <option value="M">Medium (M)</option>
            <option value="L">Large (L)</option>
            <option value="XL">Extra Large (XL)</option>
        </select> --}}
          @error('size_0')
          <span class="text-danger">{{$message}}</span>
          @enderror
          @error('price_0')
          <span class="text-danger">{{$message}}</span>
          @enderror
      </div>

        <div class="form-group">
          <label for="discount" class="col-form-label">Discount(%)</label>
          <input id="discount" type="number" name="discount" min="0" max="100" placeholder="Enter discount"  value="{{$Car->discount}}" class="form-control">
          @error('discount')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        {{-- <div class="form-group">
          <label for="size">Size</label>
          <select name="size[]" class="form-control selectpicker"  multiple data-live-search="true">
              <option value="">--Select any size--</option>
              @foreach($items as $item)              
                @php 
                $data=explode(',',$item->size);
                // dd($data);
                @endphp
              <option value="S"  @if( in_array( "S",$data ) ) selected @endif>Small</option>
              <option value="M"  @if( in_array( "M",$data ) ) selected @endif>Medium</option>
              <option value="L"  @if( in_array( "L",$data ) ) selected @endif>Large</option>
              <option value="XL"  @if( in_array( "XL",$data ) ) selected @endif>Extra Large</option>
              @endforeach
          </select>
        </div> --}}
        <div class="form-group">
          <label for="brand_id">Brand</label>
          <select name="brand_id" class="form-control">
              <option value="">--Select Brand--</option>
             @foreach($brands as $brand)
              <option value="{{$brand->id}}" {{(($Car->brand_id==$brand->id)? 'selected':'')}}>{{$brand->title}}</option>
             @endforeach
          </select>
        </div>

        <div class="form-group">
          <label for="condition">Condition</label>
          <select name="condition" class="form-control">
              <option value="">--Select Condition--</option>
              <option value="default" {{(($Car->condition=='default')? 'selected':'')}}>Default</option>
              <option value="new" {{(($Car->condition=='new')? 'selected':'')}}>New</option>
              <option value="hot" {{(($Car->condition=='hot')? 'selected':'')}}>Hot</option>
          </select>
        </div>

        <div class="form-group">
          <label for="stock">Quantity <span class="text-danger">*</span></label>
          <input id="quantity" type="number" name="stock" min="0" placeholder="Enter quantity"  value="{{$Car->stock}}" class="form-control">
          @error('stock')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group">
          <label for="inputPhoto" class="col-form-label">Photo <span class="text-danger">*</span></label>
          <div class="input-group">
            <span class="input-group-btn">
              <input type="file" class="form-control-file" name='photo'>
            </span>
        </div>
        <div id="holder" style="margin-top:15px;max-height:100px;"></div>
          @error('photo')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group ">
          <label for="inputPhoto" class="col-form-label">Photos Multiple <span class="text-danger">*</span></label>
          <div class="input-group">
              <span class="input-group-btn">
                <input type="file" class="form-control-file" name='images[]' multiple>
              </span>
        </div>
        
        <div class="form-group">
          <label for="status" class="col-form-label">Status <span class="text-danger">*</span></label>
          <select name="status" class="form-control">
            <option value="active" {{(($Car->status=='active')? 'selected' : '')}}>Active</option>
            <option value="inactive" {{(($Car->status=='inactive')? 'selected' : '')}}>Inactive</option>
        </select>
          @error('status')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group mb-3">
           <button class="btn btn-success" type="submit">Update</button>
        </div>
      </form>
    </div>
</div>

@endsection

@push('styles')
<link rel="stylesheet" href="{{asset('backend/summernote/summernote.min.css')}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />

@endpush
@push('scripts')
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script src="{{asset('backend/summernote/summernote.min.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

<script>
    $('#lfm').filemanager('image');

    $(document).ready(function() {
    $('#summary').summernote({
          placeholder: "entrer une brève description.....",

        tabsize: 2,
        height: 150
    });
    });
    $(document).ready(function() {
      $('#description').summernote({
              placeholder: "entrer une  description Detaillé.....",

          tabsize: 2,
          height: 150
      });
    });
</script>

<script>
  var  child_cat_id='{{$Car->child_cat_id}}';
        // alert(child_cat_id);
        $('#cat_id').change(function(){
            var cat_id=$(this).val();

            if(cat_id !=null){
                // ajax call
                $.ajax({
                    url:"/admin/category/"+cat_id+"/child",
                    type:"POST",
                    data:{
                        _token:"{{csrf_token()}}"
                    },
                    success:function(response){
                        if(typeof(response)!='object'){
                            response=$.parseJSON(response);
                        }
                        var html_option="<option value=''>--Select any one--</option>";
                        if(response.status){
                            var data=response.data;
                            if(response.data){
                                $('#child_cat_div').removeClass('d-none');
                                $.each(data,function(id,title){
                                    html_option += "<option value='"+id+"' "+(child_cat_id==id ? 'selected ' : '')+">"+title+"</option>";
                                });
                            }
                            else{
                                console.log('no response data');
                            }
                        }
                        else{
                            $('#child_cat_div').addClass('d-none');
                        }
                        $('#child_cat_id').html(html_option);

                    }
                });
            }
            else{

            }

        });
        if(child_cat_id!=null){
            $('#cat_id').change();
        }
</script>
@endpush